# 1. Create a new folder
mkdir love-confession
cd love-confession

# 2. Initialize project
npm create vite@latest . -- --template react-ts

# 3. Install dependencies
npm install framer-motion lucide-react

# 4. Copy all my files (maintaining the folder structure)

# 5. Run locally to test
npm run dev

# 6. Deploy to Vercel
npx vercel